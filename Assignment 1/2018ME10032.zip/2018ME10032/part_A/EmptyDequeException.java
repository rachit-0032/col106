public class EmptyDequeException extends Exception{  
    EmptyDequeException(String s){  
        super(s);  
    }  
}