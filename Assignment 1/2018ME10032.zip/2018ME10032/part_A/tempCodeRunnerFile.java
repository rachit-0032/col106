r(int i = 0; i < N; i++) {
    //   myDeque.insertFirst(i);
    //   // myDeque.insertLast(-1*i);
    // }