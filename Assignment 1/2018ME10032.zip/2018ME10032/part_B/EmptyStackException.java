public class EmptyStackException extends Exception{
    EmptyStackException(String s){
        super(s);
    }
}