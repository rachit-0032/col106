public class ArrayDeque implements DequeInterface {

  public void insertFirst(Object o){
    //you need to implement this
    throw new java.lang.UnsupportedOperationException("Not implemented yet.");
  }
  
  public void insertLast(Object o){
    //you need to implement this
    throw new java.lang.UnsupportedOperationException("Not implemented yet.");
  }
  
  public Object removeFirst() throws EmptyDequeException{
    //you need to implement this
    throw new java.lang.UnsupportedOperationException("Not implemented yet.");
  }
  
  public Object removeLast() throws EmptyDequeException{
    //you need to implement this
    throw new java.lang.UnsupportedOperationException("Not implemented yet.");
  }

  public Object first() throws EmptyDequeException{
    //you need to implement this
    throw new java.lang.UnsupportedOperationException("Not implemented yet.");
  }
  
  public Object last() throws EmptyDequeException{
    //you need to implement this
    throw new java.lang.UnsupportedOperationException("Not implemented yet.");
  }
  
  public int size(){
    //you need to implement this
    throw new java.lang.UnsupportedOperationException("Not implemented yet.");
  }
  
  public boolean isEmpty(){
    //you need to implement this
    throw new java.lang.UnsupportedOperationException("Not implemented yet.");
  }

  public String toString(){
    //you need to implement this
    throw new java.lang.UnsupportedOperationException("Not implemented yet.");
  }  
}