public class FabricBreakup {	
	public static void main(String args[]){
		// Implement FabricBreakup puzzle using Stack interface
	}
}
