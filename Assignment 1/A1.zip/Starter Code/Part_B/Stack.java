// You should utilise your implementation of ArrayDeque methods to implement this
public class Stack implements StackInterface {	
	public void push(Object o){
    	//you need to implement this
    	throw new java.lang.UnsupportedOperationException("Not implemented yet.");
  	}

	public Object pop() throws EmptyStackException{
    	//you need to implement this
    	throw new java.lang.UnsupportedOperationException("Not implemented yet.");
	}

	public Object top() throws EmptyStackException{
    	//you need to implement this
    	throw new java.lang.UnsupportedOperationException("Not implemented yet.");
	}

	public boolean isEmpty(){
    	//you need to implement this
    	throw new java.lang.UnsupportedOperationException("Not implemented yet.");
	}

    public int size(){
    	//you need to implement this
    	throw new java.lang.UnsupportedOperationException("Not implemented yet.");
    }
}